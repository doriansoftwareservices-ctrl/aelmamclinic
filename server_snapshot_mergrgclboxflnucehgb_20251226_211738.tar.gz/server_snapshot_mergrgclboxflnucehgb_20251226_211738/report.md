# Server Snapshot (Nhost/Hasura)
- Subdomain: `mergrgclboxflnucehgb`
- Region: `ap-southeast-1`
- Generated: `2025-12-26T21:17:38+03:00`
- Output folder: `server_snapshot_mergrgclboxflnucehgb_20251226_211738`

## Tooling
```
Python 3.12.3
```

## Nhost config validate
```
Getting secrets...
Config is valid!
```

## Secrets (names only)
```
HASURA_GRAPHQL_ADMIN_SECRET
HASURA_GRAPHQL_JWT_SECRET
NHOST_WEBHOOK_SECRET
GRAFANA_ADMIN_PASSWORD
```

## Deployments list
```
                                      │                      │              │          │                             │                                          │                                                       │
 ID                                   │ Date                 │ Duration     │ Status   │ User                        │ Ref                                      │ Message                                               │
 1dbbec24-53d5-4801-9207-5a39ef4b7af4 │ 2025-12-26T18:09:07Z │ 1m12.82443s  │ DEPLOYED │ doriansoftwareservices-ctrl │ fb74f3bbb3d6b6ebb8034665f78bed5992c271df │ chore: trigger redeploy                               │
 65f31822-5c2e-4f58-b94d-25afdb02280d │ 2025-12-26T18:02:07Z │ 1m9.886699s  │ FAILED   │ doriansoftwareservices-ctrl │ 4dc6351e363a3217062da5cef4ee7c95b0fea6fa │ fix: remove admin permission from v_chat_last_message │
 bbf4da1f-3c22-4fd8-8210-6f51f8d03026 │ 2025-12-26T17:53:57Z │ 1m12.48636s  │ DEPLOYED │ doriansoftwareservices-ctrl │ d4ca1a4d4b4255082534a89f65e7285916ee7dcf │ fix: drop payment stats funcs before return change    │
 87b8d9d5-0e2b-4076-acc3-eb77aef38f42 │ 2025-12-26T17:48:17Z │ 47.062502s   │ FAILED   │ doriansoftwareservices-ctrl │ 4227153e8f8c0830c4e6f831c36deaacc01f06bd │ fix: resolve hasura metadata inconsistencies          │
 ff2226f8-25bc-419a-8a16-9bf33b9baa76 │ 2025-12-26T17:28:57Z │ 1m15.551484s │ DEPLOYED │ doriansoftwareservices-ctrl │ ec1e5bf744c492a8794f2f1e1d9418469522e8b8 │ fix: send _text array literal for sync_super_admins   │
 1e3e0bfb-d1cf-494c-bf74-a8a29bf1dfc2 │ 2025-12-26T17:23:07Z │ 1m11.981919s │ DEPLOYED │ doriansoftwareservices-ctrl │ 6516732d39d41f81acb2822609db9b02b91acbee │ fix: sync_super_admins gql _text param                │
 596e43cb-3b0c-4f25-9cba-7998aaa472f5 │ 2025-12-26T17:06:07Z │ 1m12.876218s │ DEPLOYED │ doriansoftwareservices-ctrl │ 210bd36295bafe6b161faea81a74e27847871235 │ fix: make sync_super_admins runnable with dart        │
 76592058-a0fd-4962-8853-ace9604b041c │ 2025-12-26T16:56:07Z │ 1m11.773115s │ DEPLOYED │ doriansoftwareservices-ctrl │ 498098a06ee4919c20796d88c52c0c6a2137386c │ chore: trigger redeploy                               │
 1c2e01f0-7b6b-4e7a-bd36-92ac8500bd4b │ 2025-12-26T16:43:57Z │ 1m11.177869s │ FAILED   │ doriansoftwareservices-ctrl │ f65ed85a9f7da32c3f86b7bdd4bea71de7132afd │ fix: drop RPCs before return type changes             │
 8332d8a7-5954-418d-9d36-5874f9db0d5c │ 2025-12-26T16:41:17Z │ 48.106929s   │ FAILED   │ doriansoftwareservices-ctrl │ 5026e801dbe56286554b14771c8bccddb0cd578c │ Fix backend metadata/migrations and app flows         │
                                      │                      │              │          │                             │                                          │                                                       │
```

## Hasura export_metadata
Saved: server_snapshot_mergrgclboxflnucehgb_20251226_211738/hasura_export_metadata.json

## DB inventory
Saved:
- server_snapshot_mergrgclboxflnucehgb_20251226_211738/db_version.json
- server_snapshot_mergrgclboxflnucehgb_20251226_211738/db_objects.json
- server_snapshot_mergrgclboxflnucehgb_20251226_211738/db_functions.json
- server_snapshot_mergrgclboxflnucehgb_20251226_211738/db_policies.json

## GraphQL introspection
Saved: server_snapshot_mergrgclboxflnucehgb_20251226_211738/graphql_introspection.json

