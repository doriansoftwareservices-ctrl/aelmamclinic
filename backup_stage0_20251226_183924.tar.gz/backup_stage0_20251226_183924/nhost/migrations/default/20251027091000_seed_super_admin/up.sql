-- 20251027091000_seed_super_admin.sql
-- No-op: super admins must be managed via public.super_admins.

SELECT 1;
