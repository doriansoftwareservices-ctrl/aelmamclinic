-- Placeholder migration.
SELECT 1;
