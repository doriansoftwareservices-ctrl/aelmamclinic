DROP FUNCTION IF EXISTS public.debug_auth_context();
