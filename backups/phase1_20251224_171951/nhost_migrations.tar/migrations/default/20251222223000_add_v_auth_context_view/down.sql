DROP VIEW IF EXISTS public.v_auth_context;
