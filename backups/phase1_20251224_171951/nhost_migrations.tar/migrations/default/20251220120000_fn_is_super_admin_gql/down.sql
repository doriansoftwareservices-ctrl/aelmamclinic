DROP FUNCTION IF EXISTS public.fn_is_super_admin_gql();
