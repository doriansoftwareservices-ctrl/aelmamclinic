-- No-op: super admins must be managed via public.super_admins.

SELECT 1;
