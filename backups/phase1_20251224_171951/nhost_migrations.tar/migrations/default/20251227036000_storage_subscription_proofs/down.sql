DELETE FROM storage.buckets
WHERE id = 'subscription-proofs';
