DROP TABLE IF EXISTS public.account_users;
DROP TABLE IF EXISTS public.accounts;
