DROP FUNCTION IF EXISTS public.debug_auth_context();
DROP VIEW IF EXISTS public.v_debug_auth_context;
