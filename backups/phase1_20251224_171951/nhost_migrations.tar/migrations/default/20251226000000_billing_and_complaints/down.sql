-- Irreversible migration (keeps billing data).
SELECT 1;
