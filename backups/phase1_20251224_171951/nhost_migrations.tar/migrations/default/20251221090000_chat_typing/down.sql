-- 20251221090000_chat_typing.sql

SET search_path TO public;

DROP VIEW IF EXISTS public.v_chat_typing_active;
DROP TABLE IF EXISTS public.chat_typing;
